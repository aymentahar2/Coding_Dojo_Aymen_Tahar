# print("hello world")

# name="Aymen"
# # print("hello",name)

# # print("hello "+ name)

# Num="45"
# # print("hello",Num)

# print("hello "+ Num)

# print("i love to eat {food_one} and {food_two}".format(food_one= "kosksi", food_two = "lablabi"))


food_one="kosksi"
food_two="lablabi"

print(f"i love to eat {food_one} and {food_two}")

