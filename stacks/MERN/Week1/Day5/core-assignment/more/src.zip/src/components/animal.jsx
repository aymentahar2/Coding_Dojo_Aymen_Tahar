import React from 'react'

const Animal = (props) => {
    return (
        <div>{props.el}</div>
    )
}

export default Animal;