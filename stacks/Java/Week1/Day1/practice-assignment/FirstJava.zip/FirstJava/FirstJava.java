public class FirstJava {
    public static void main ( String[] args) {
        System.out.println("My name is Aymen Tahar");
        System.out.println("I'm 26 YO");
        System.out.println("MY homeTown is beng");
    }
}